var class_cursor_entity =
[
    [ "Update", "db/d01/class_cursor_entity.html#aa78ef4b1bd3c6fe1774fb3c5b794be63", null ],
    [ "Update", "db/d01/class_cursor_entity.html#ae4effbe4b83dde06868bdbb3b74ea341", null ]
];