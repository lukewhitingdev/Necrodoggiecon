var class_c_component =
[
    [ "Draw", "de/d11/class_c_component.html#a77aa6488f05864f14f9cc0c2dce1b93c", null ],
    [ "GetWorldPosition", "de/d11/class_c_component.html#a2924c299a04048303a2291e2417be178", null ],
    [ "SetAnchor", "de/d11/class_c_component.html#a37ed76dec52a20ee963f16ae7803532a", null ],
    [ "SetIsUI", "de/d11/class_c_component.html#aa2179d1b3e13644e4b4474ae7b7babc0", null ],
    [ "SetLastResolution", "de/d11/class_c_component.html#a473b86fd801a4581b4f4bec21184ba4d", null ],
    [ "SetName", "de/d11/class_c_component.html#a582698e4b340a4dee4ee47f231bd7988", null ],
    [ "SetParent", "de/d11/class_c_component.html#a0eee7990d6d3e9a7947e03f214e184c0", null ],
    [ "SetShouldDraw", "de/d11/class_c_component.html#a0eb2309792c8dd2fe1b0416afd5521a7", null ],
    [ "SetShouldUpdate", "de/d11/class_c_component.html#a63aafb634d577f248b07baf6c7893035", null ],
    [ "SetUseTranslucency", "de/d11/class_c_component.html#aa477a05535b1d092eac86a27364d2434", null ],
    [ "Update", "de/d11/class_c_component.html#a14c688a726b92d4152365b84c37a90ff", null ]
];