var class_c_entity =
[
    [ "RemoveComponent", "dc/d3b/class_c_entity.html#ad99b5ffe95f5744397b0142d5b40eda4", null ],
    [ "SetIsUI", "dc/d3b/class_c_entity.html#af7b3c8a4e39bb4ed0dd565e406ca5cb7", null ],
    [ "SetShouldMove", "dc/d3b/class_c_entity.html#a4b32c1fd61ca1ee5804daea441cc9c41", null ],
    [ "SetShouldUpdate", "dc/d3b/class_c_entity.html#a60b61ccd5eab208ed0ac31e8174ad5d5", null ],
    [ "SetVisible", "dc/d3b/class_c_entity.html#afbaed7092fcd98125ac0512e21688d3a", null ],
    [ "Update", "dc/d3b/class_c_entity.html#aa2f9a3d39dfac2ad93022b0805e13e17", null ]
];