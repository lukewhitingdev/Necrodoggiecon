var _c_text_render_component_8h =
[
    [ "CTextRenderComponent", "df/d16/class_c_text_render_component.html", "df/d16/class_c_text_render_component" ],
    [ "TextJustification", "dc/d1a/_c_text_render_component_8h.html#a9cbcbda0acf4d1a69c9c7d6240314217", [
      [ "Right", "dc/d1a/_c_text_render_component_8h.html#a9cbcbda0acf4d1a69c9c7d6240314217a92b09c7c48c520c3c55e497875da437c", null ],
      [ "Center", "dc/d1a/_c_text_render_component_8h.html#a9cbcbda0acf4d1a69c9c7d6240314217a4f1f6016fc9f3f2353c0cc7c67b292bd", null ],
      [ "Left", "dc/d1a/_c_text_render_component_8h.html#a9cbcbda0acf4d1a69c9c7d6240314217a945d5e233cf7d6240f6b783b36a374ff", null ]
    ] ]
];