var class_c_widget___canvas =
[
    [ "CreateButton", "d8/d0c/class_c_widget___canvas.html#a99d9f145f961709726ce8678f230f10f", null ],
    [ "CreateImage", "d8/d0c/class_c_widget___canvas.html#a80981ed2d19038585e407245a3c88dc9", null ],
    [ "CreateText", "d8/d0c/class_c_widget___canvas.html#ab314f33e4f87b3391ae237f23be4e575", null ],
    [ "GetMousePosition", "d8/d0c/class_c_widget___canvas.html#a03f59ecee548c298c5b7dacafb29d524", null ],
    [ "InitialiseCanvas", "d8/d0c/class_c_widget___canvas.html#aebab715ffc05a552cf625019189933f0", null ],
    [ "SetVisibility", "d8/d0c/class_c_widget___canvas.html#a47fa9ceefb38f24fb999abb3a39240a9", null ],
    [ "Update", "d8/d0c/class_c_widget___canvas.html#a2dd86bd46f51e9ba7377c421556d7910", null ],
    [ "buttonList", "d8/d0c/class_c_widget___canvas.html#a4b9017757d42524e777b0b0523731bca", null ]
];