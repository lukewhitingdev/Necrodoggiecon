var class_c_widget___image =
[
    [ "SetVisibility", "d6/d3b/class_c_widget___image.html#a853bd5444cb05e9a1ebf12675d4811cd", null ],
    [ "SetWidgetTransform", "d6/d3b/class_c_widget___image.html#af94dbff630726d45aa8bd8f6feb353a0", null ],
    [ "Update", "d6/d3b/class_c_widget___image.html#aa2857ba92595298f61398dcf0d182130", null ]
];