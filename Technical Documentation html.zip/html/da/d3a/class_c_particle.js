var class_c_particle =
[
    [ "Draw", "da/d3a/class_c_particle.html#a9a4a143620dbd2dfa375dad0088a62d1", null ],
    [ "GetDirection", "da/d3a/class_c_particle.html#a4dd3f13266fe76b3defc44bda754dd50", null ],
    [ "GetLifetime", "da/d3a/class_c_particle.html#afcd30f723ac851bea12de33be1304c6d", null ],
    [ "getSpriteComponent", "da/d3a/class_c_particle.html#aa5f68df4312299ae7cbddcf283d4564c", null ],
    [ "GetVelocity", "da/d3a/class_c_particle.html#a7bc909de6e19a397e806d9a79f02dd24", null ],
    [ "SetDirection", "da/d3a/class_c_particle.html#a8530a4ea8b90bb61d8b1eb456177420b", null ],
    [ "SetLifetime", "da/d3a/class_c_particle.html#aa7143601d57f382b07b0c27abe6c284d", null ],
    [ "SetVelocity", "da/d3a/class_c_particle.html#a9253e1b4c80dc4f9020c521d9a373ea4", null ],
    [ "Update", "da/d3a/class_c_particle.html#a6f13d1bdd40a8bde836b25eaa3c441cf", null ]
];