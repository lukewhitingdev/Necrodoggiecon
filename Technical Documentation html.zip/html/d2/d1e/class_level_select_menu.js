var class_level_select_menu =
[
    [ "CloseMenu", "d2/d1e/class_level_select_menu.html#ac314cee1486aa035e8813d40fd36027c", null ],
    [ "OpenLevel1", "d2/d1e/class_level_select_menu.html#a4f9b756ee703fea2dba8c5752d04ec9e", null ],
    [ "OpenLevel2", "d2/d1e/class_level_select_menu.html#a042fd9326ea092c4b3e5852f22fcc972", null ],
    [ "OpenLevel3", "d2/d1e/class_level_select_menu.html#a5ff44a60a78077fef794e55f762fe782", null ],
    [ "OpenLevel4", "d2/d1e/class_level_select_menu.html#a3fa6cfab156fd9ebe07777a4f9193e22", null ],
    [ "OpenLevel5", "d2/d1e/class_level_select_menu.html#a70f029e20bae77628033022448f351ef", null ],
    [ "OpenLevel6", "d2/d1e/class_level_select_menu.html#a78ac8a8465e9c56c97c97e4db434248f", null ],
    [ "OpenLevel7", "d2/d1e/class_level_select_menu.html#a4462239cc9ca7e9dbddaa6a0eead2006", null ],
    [ "OpenLevelTutorial", "d2/d1e/class_level_select_menu.html#a7d1f739ad3687c4108742a66b884f70f", null ],
    [ "PlayLevel", "d2/d1e/class_level_select_menu.html#af975737258998997e0b3ff964767ed7d", null ],
    [ "UpdateButtonPositions", "d2/d1e/class_level_select_menu.html#a9e95da075f73a2f328bffe38bb992630", null ]
];