var class_magic_missile =
[
    [ "OnFire", "d7/d1b/class_magic_missile.html#a807a5ab7a9df795d8cadf8e708768e45", null ]
];