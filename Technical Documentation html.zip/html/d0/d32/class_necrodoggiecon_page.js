var class_necrodoggiecon_page =
[
    [ "OnInteract", "d0/d32/class_necrodoggiecon_page.html#adfae3504b355b39b00a22d71f803e95a", null ]
];