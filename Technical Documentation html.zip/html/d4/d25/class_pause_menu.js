var class_pause_menu =
[
    [ "OpenSettingsMenu", "d4/d25/class_pause_menu.html#aadffad284822a193eb7e4d9890a92f0e", null ],
    [ "PauseGame", "d4/d25/class_pause_menu.html#a034d082d89cffbb7daa102033d155248", null ],
    [ "QuitToDesktop", "d4/d25/class_pause_menu.html#afe9df46cd23e693d25466ea763d4263b", null ],
    [ "QuitToMenu", "d4/d25/class_pause_menu.html#a04bc316028c7d2038173217c3cb6f54c", null ],
    [ "ResumeGame", "d4/d25/class_pause_menu.html#a0763dfecee722a895acd7e4fcf4e8f6d", null ],
    [ "Update", "d4/d25/class_pause_menu.html#a40e55b192a4a63cecccf07f9ebe69f91", null ]
];