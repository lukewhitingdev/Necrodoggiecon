var class_crossbow =
[
    [ "Update", "d4/d01/class_crossbow.html#a3b414930518555d7f706fc023769064a", null ]
];