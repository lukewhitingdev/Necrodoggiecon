var class_level_complete_menu =
[
    [ "NextLevel", "d9/d34/class_level_complete_menu.html#a5b7058b4c0daaef181701b55ff5108a7", null ],
    [ "QuitToDesktop", "d9/d34/class_level_complete_menu.html#a7540dd1611624ddfe76ae0c5f8fb1098", null ],
    [ "QuitToMenu", "d9/d34/class_level_complete_menu.html#ab9e11509fdc6b7cc8927c99b74f3b744", null ]
];