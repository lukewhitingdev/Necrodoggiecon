var class_dialogue_u_i =
[
    [ "DialogueUI", "d9/d29/class_dialogue_u_i.html#a7bf4169280c53f4735ccc2d7eebd7c04", null ],
    [ "Advance", "d9/d29/class_dialogue_u_i.html#a776e4fa922aba781f7837fe1957a3620", null ],
    [ "ClearText", "d9/d29/class_dialogue_u_i.html#a24e1447371b40ed1fb2bb3e1b2629601", null ],
    [ "CompletePage", "d9/d29/class_dialogue_u_i.html#aa50b4264948be95cdec08571943dcb6c", null ],
    [ "IsComplete", "d9/d29/class_dialogue_u_i.html#ad21cd07c55ba4b6a814628fa8b99d70c", null ],
    [ "SetName", "d9/d29/class_dialogue_u_i.html#a4d5e47b699fb63f4326cb119ca8fd7d0", null ],
    [ "SetText", "d9/d29/class_dialogue_u_i.html#ac10682f8a1962159cb6cd7ede9be3f94", null ],
    [ "ToggleDrawing", "d9/d29/class_dialogue_u_i.html#a8170d54599a32291bd2e128d1be06b76", null ],
    [ "Update", "d9/d29/class_dialogue_u_i.html#a7321c0da526d725472d217597d792d9d", null ]
];