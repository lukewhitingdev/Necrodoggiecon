var class_melee_weapon =
[
    [ "OnFire", "d9/d2c/class_melee_weapon.html#a5b54eda37285df4189e0de18fc455ae3", null ]
];