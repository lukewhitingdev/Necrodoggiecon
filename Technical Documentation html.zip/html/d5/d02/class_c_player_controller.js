var class_c_player_controller =
[
    [ "HandleInput", "d5/d02/class_c_player_controller.html#ab2ec691d21ac651c1d7663bb412c2cbf", null ],
    [ "Possess", "d5/d02/class_c_player_controller.html#a85ce3c21b8f9954e78fe5d58a3bd2d7a", null ],
    [ "Unpossess", "d5/d02/class_c_player_controller.html#ae1264f5a5b25a4811b614b54bbb65d86", null ]
];