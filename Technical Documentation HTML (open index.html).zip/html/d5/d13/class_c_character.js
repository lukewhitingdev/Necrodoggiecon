var class_c_character =
[
    [ "ApplyDamage", "d5/d13/class_c_character.html#abb7e492a1d48a9561ca186c5e1540aa2", null ],
    [ "Update", "d5/d13/class_c_character.html#a66ce2ef2e7976efbc25414eb502a66b6", null ]
];