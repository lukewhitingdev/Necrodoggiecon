var class_c_widget =
[
    [ "AddChild", "d5/d2c/class_c_widget.html#aed97b4e9c89e68ef18ba0ed75b8e4038", null ],
    [ "RemoveAllChildren", "d5/d2c/class_c_widget.html#a4ff797d22a1bf33a16458b74b51bc003", null ],
    [ "SetVisibility", "d5/d2c/class_c_widget.html#ade0b37b68bb0c877fb48c22081973093", null ],
    [ "SetWidgetTransform", "d5/d2c/class_c_widget.html#a0748f222db0c0ad58b9bc88fa1f89aa0", null ],
    [ "UpdateWidgetOrigin", "d5/d2c/class_c_widget.html#ab6456cbbeddba1e6fc905f03e7153026", null ]
];