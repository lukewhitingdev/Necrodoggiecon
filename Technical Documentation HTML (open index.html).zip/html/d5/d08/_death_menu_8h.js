var _death_menu_8h =
[
    [ "DeathMenu", "dd/d2c/class_death_menu.html", "dd/d2c/class_death_menu" ]
];