var class_longsword =
[
    [ "OnFire", "d9/d0d/class_longsword.html#a2306689fd4e90c4965363cf14ab67125", null ]
];