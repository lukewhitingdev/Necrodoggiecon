var class_homing_projectile =
[
    [ "Update", "d8/d0e/class_homing_projectile.html#ab2e50f695183a2ee2347721992499448", null ]
];