var class_main_menu =
[
    [ "OpenLevelSelect", "d4/d04/class_main_menu.html#acf40647e5513624be6dd462ddc39ba44", null ],
    [ "OpenSettingsMenu", "d4/d04/class_main_menu.html#a02cf19f4a9ec2a996c8d2d967e4bdf10", null ],
    [ "QuitToDesktop", "d4/d04/class_main_menu.html#a8582cfd31d39a8abc0130170ab50ae41", null ]
];