var class_dog_enemy =
[
    [ "AttackEnter", "d4/d11/class_dog_enemy.html#afcdf77851866b0d2a0bbc7277a9911f8", null ],
    [ "AttackPlayer", "d4/d11/class_dog_enemy.html#a03b5de2cc68e611a6177186de65a6104", null ],
    [ "ChasePlayer", "d4/d11/class_dog_enemy.html#ac5b0efac141d42266b8ec896c2cbca8f", null ],
    [ "Update", "d4/d11/class_dog_enemy.html#a9c0b9a3b5ce7858a4ba08a1e71f35790", null ]
];