var class_settings_menu =
[
    [ "CloseSettings", "d4/d14/class_settings_menu.html#aea818954d9672d5e12dba1a50e991378", null ],
    [ "Update", "d4/d14/class_settings_menu.html#a84071d3783b6874634f539874ca0d7af", null ]
];