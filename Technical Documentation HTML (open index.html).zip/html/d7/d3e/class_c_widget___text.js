var class_c_widget___text =
[
    [ "CWidget_Text", "d7/d3e/class_c_widget___text.html#a68887aadb4b0e04bc599a4cc595c1fc0", null ],
    [ "SetVisibility", "d7/d3e/class_c_widget___text.html#a47cab7297df35506e9e38f35651121e1", null ],
    [ "SetWidgetTransform", "d7/d3e/class_c_widget___text.html#ac4b8ea19614ad95ce92d93d3f68a41b0", null ],
    [ "Update", "d7/d3e/class_c_widget___text.html#a326e3837a4dc63ba2798d74674f0622d", null ]
];