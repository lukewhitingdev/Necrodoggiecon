var _c_material_8h =
[
    [ "_Material", "d7/d29/struct___material.html", null ],
    [ "MaterialPropertiesConstantBuffer", "d7/d21/struct_material_properties_constant_buffer.html", null ],
    [ "CMaterial", "dc/d2a/struct_c_material.html", null ]
];