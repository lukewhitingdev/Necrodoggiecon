var class_c_sprite_component =
[
    [ "Draw", "db/d2e/class_c_sprite_component.html#a378fd1989f5b86f84a22749f9a087b78", null ],
    [ "LoadTexture", "db/d2e/class_c_sprite_component.html#ab5904978b0c448cf3c67f12f9939b48b", null ],
    [ "LoadTextureWIC", "db/d2e/class_c_sprite_component.html#a06c1b60995360c1902e07652d72e49e3", null ],
    [ "SetRenderRect", "db/d2e/class_c_sprite_component.html#ab48a11af45329356b4c2d47551bfecd4", null ],
    [ "SetSpriteSize", "db/d2e/class_c_sprite_component.html#a95c8bd7fcf812d01d7b3251de9357727", null ],
    [ "SetTextureOffset", "db/d2e/class_c_sprite_component.html#af2cffbcab3778aee3a9f0d32f5fb7482", null ],
    [ "SetTint", "db/d2e/class_c_sprite_component.html#af4674cb1889ac605235184906ee31a42", null ],
    [ "SetUseTranslucency", "db/d2e/class_c_sprite_component.html#a039d54e8c196a80b9f1f0a418d1bed1d", null ],
    [ "Update", "db/d2e/class_c_sprite_component.html#a6f46a08bf1147717a480780947cd1437", null ]
];